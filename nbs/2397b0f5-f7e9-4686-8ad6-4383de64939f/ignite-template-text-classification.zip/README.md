[![Code-Generator](https://badgen.net/badge/Template%20by/Code-Generator/ee4c2c?labelColor=eaa700)](https://github.com/pytorch-ignite/code-generator)

# Text Classification Template

This is the text classification template by Code-Generator using `bert-base-uncased` model from HuggingFace Transformers and `imdb` dataset from HuggingFace datasets and training is powered by PyTorch and PyTorch-Ignite.

## Getting Started

Install the dependencies with `pip`:

```sh
pip install -r requirements.txt --progress-bar off -U
```

## Training

### Multi Node, Multi GPU Training (`torchrun`) (recommended)

- Execute on master node

```sh
torchrun \
  --nproc_per_node 2 \
  --nnodes 2 \
  --node_rank 0 \
  --master_addr 127.0.0.1 \
  --master_port 8080 \
  main.py \
  --backend nccl
```

- Execute on worker nodes

```sh
torchrun \
  --nproc_per_node 2 \
  --nnodes 2 \
  --node_rank <node_rank> \
  --master_addr 127.0.0.1 \
  --master_port 8080 \
  main.py \
  --backend nccl
```
