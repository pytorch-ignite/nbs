import os
import tempfile
from argparse import Namespace
from pathlib import Path
from typing import Iterable

import ignite.distributed as idist
import pytest
import torch
from data import setup_data
from omegaconf import OmegaConf
from torch import nn, optim, Tensor
from torch.utils.data.dataloader import DataLoader
from trainers import setup_evaluator
from utils import save_config


def set_up():
    model = nn.Linear(1, 1)
    optimizer = optim.Adam(model.parameters())
    device = idist.device()
    loss_fn = nn.MSELoss()
    batch = [torch.tensor([1.0]), torch.tensor([1.0])]

    return model, optimizer, device, loss_fn, batch


@pytest.mark.skipif(os.getenv("RUN_SLOW_TESTS", 0) == 0, reason="Skip slow tests")
def test_setup_data():
    config = Namespace(data_path="~/data", batch_size=1, eval_batch_size=1, num_workers=0)
    dataloader_train, dataloader_eval = setup_data(config)

    assert isinstance(dataloader_train, DataLoader)
    assert isinstance(dataloader_eval, DataLoader)
    train_batch = next(iter(dataloader_train))
    assert isinstance(train_batch, Iterable)
    assert isinstance(train_batch[0], Tensor)
    assert isinstance(train_batch[1], Tensor)
    assert train_batch[0].ndim == 4
    assert train_batch[1].ndim == 1
    eval_batch = next(iter(dataloader_eval))
    assert isinstance(eval_batch, Iterable)
    assert isinstance(eval_batch[0], Tensor)
    assert isinstance(eval_batch[1], Tensor)
    assert eval_batch[0].ndim == 4
    assert eval_batch[1].ndim == 1


def test_setup_evaluator():
    model, _, device, _, batch = set_up()
    config = Namespace(use_amp=False)
    evaluator = setup_evaluator(config, model, device)
    evaluator.run([batch, batch])
    assert isinstance(evaluator.state.output, tuple)


def test_save_config():
    with open("./config.yaml", "r") as f:
        config = OmegaConf.load(f)

    # Add backend to config (similar to setup_config)
    config.backend = None

    with tempfile.TemporaryDirectory() as output_dir:
        output_dir = Path(output_dir)

        save_config(config, output_dir)

        with open(output_dir / "config-lock.yaml", "r") as f:
            test_config = OmegaConf.load(f)

        assert config == test_config
